# সাদিয়া এআই (Sadia AI)

Developed by Samir — personal Bangla voice assistant for Android, built with
Kotlin + Jetpack Compose.

## লঞ্চার আইকন

তোমার দেওয়া "Sadia AI" নিয়ন লোগো থেকে সব ডেনসিটির আইকন (mipmap-mdpi থেকে
xxxhdpi), round আইকন, adaptive icon (foreground + কালো background) এবং
Play Store-এর জন্য ৫১২x৫১২ হাই-রেজ আইকন (`play_store_icon_512.png`,
প্রজেক্টের রুটে) — সব আগে থেকেই বানিয়ে `res/mipmap-*` ও `res/drawable-*`
ফোল্ডারে বসানো আছে। নতুন করে কিছু করতে হবে না।

## Termux দিয়ে এক-ক্লিকে বিল্ড (ফোনেই, কম্পিউটার লাগবে না)

1. Play Store/F-Droid থেকে **Termux** ইনস্টল করো (F-Droid ভার্সনটাই ভালো
   কাজ করে)। ঐচ্ছিক কিন্তু সুবিধাজনক: **Termux:API** অ্যাপ+প্যাকেজও ইনস্টল
   করে নাও — এটা থাকলে বিল্ড শেষে APK নিজে থেকেই ইনস্টলারে খুলে যাবে।
2. `SadiaAI.zip` ফোনের Downloads ফোল্ডারে রাখো, তারপর Termux-এ:
   ```bash
   termux-setup-storage
   cd ~/storage/downloads
   unzip SadiaAI.zip
   cd SadiaAI
   bash termux_build.sh
   ```
3. প্রথমবার চালালে Android SDK ডাউনলোড+ইনস্টল হতে ইন্টারনেট স্পিড অনুযায়ী
   ১০–২৫ মিনিট লাগতে পারে (SDK + build-tools প্রায় ১-১.৫ জিবি)। পরের বার
   থেকে স্কিপ হয়ে শুধু বিল্ড হবে, কয়েক মিনিটেই শেষ।
4. শেষে `app-debug.apk` তৈরি হয়ে Downloads/SadiaAI.apk-তেও কপি হয়ে যাবে।
   Termux:API থাকলে ইনস্টলার নিজে থেকেই খুলবে; না থাকলে ফাইল ম্যানেজার
   দিয়ে গিয়ে ট্যাপ করে ইনস্টল করো ("Install from unknown sources" অনুমতি
   চাইতে পারে, একবার দিয়ে দিলেই হবে)।
5. পরে যেকোনো সময় শুধু `bash termux_build.sh` আবার চালালেই নতুন বিল্ড হয়ে
   যাবে — কোড পরিবর্তন করলেও এই একই কমান্ডই চলবে।

**যদি বিল্ড ব্যর্থ হয় aapt2 "cannot execute" জাতীয় এররে** (কিছু Termux
সেটআপে নেটিভ Android SDK বাইনারি সরাসরি চলে না): তখন
`pkg install proot-distro && proot-distro install ubuntu` দিয়ে একটা Ubuntu
chroot বানিয়ে, `proot-distro login ubuntu`-এর ভেতরে গিয়ে একই প্রজেক্টে
`bash termux_build.sh` চালাও (তবে সেই ভেতরের Ubuntu-তে আলাদাভাবে
`apt install openjdk-17-jdk-headless wget unzip`-ও করে নিতে হবে, কারণ সেটা
আলাদা environment)।

## Open in Android Studio

1. `File → Open` this folder (Koala/Ladybug or newer — needs AGP 8.5+, Kotlin 1.9.24).
2. Let Gradle sync. No wrapper jar is included in this export — if your
   Android Studio doesn't auto-generate one, run `gradle wrapper --gradle-version 8.7`
   once from a terminal in this folder, or just open the project and let
   Android Studio offer to create the wrapper.
3. Add a launcher icon at `app/src/main/res/mipmap-*/ic_launcher.png` (not
   included) or swap `android:icon` in the manifest for a vector drawable.
4. Build & run on a device running Android 8.0 (API 26) or newer — the
   Accessibility/automation features need a real device, not the emulator's
   limited virtual sensors, for WhatsApp/flashlight/system-settings actions.

## First run

1. Grant microphone permission when prompted.
2. Open **Settings → Gemini API কী**, paste your own Gemini API key
   (from Google AI Studio), tap সেভ করুন. The key is stored only on-device
   via `EncryptedSharedPreferences` (AES-256-GCM) — it never touches any
   server of ours.
3. In the **পারমিশন উইজার্ড** card, tap চালু করুন next to Accessibility
   Service and Notification Access, and enable "সাদিয়া এআই" in the system
   dialogs that open. Android requires these to be granted manually in
   Settings — no app can auto-grant them.
4. Back on the home screen, tap the mic button and talk.

## Architecture

- **gemini/GeminiLiveClient.kt** — raw OkHttp WebSocket client for Gemini's
  Live (`BidiGenerateContent`) API: sends 16kHz PCM16 mic audio, receives
  24kHz PCM16 model audio + transcripts, and surfaces `interrupted` events
  for barge-in.
- **gemini/AudioEngine.kt** — `AudioRecord`/`AudioTrack` wrapper; exposes
  live RMS amplitude flows that drive the orb's reactive glow.
- **accessibility/SadiaAccessibilityService.kt** — the automation engine:
  app launching, the WhatsApp send flow, call/flashlight/WiFi/Bluetooth
  toggles, and screen-tree traversal helpers. Sensitive actions always go
  through `SadiaAutomationBridge.requestConfirmation()` first, which the
  ViewModel resolves after asking the user aloud.
- **data/local/** — Room database (conversations, messages, long-term
  memory facts, automation task log).
- **ui/** — the 3-layer Compose UI: `VoiceScreen` (orb + mic), `ChatHistoryScreen`
  (transcript + task log cards), `SettingsScreen` (API key, voice/speed,
  permission wizard).

## Known gaps to finish before a store release

- **Gemini Live model name**: `models/gemini-2.0-flash-live-001` is set as
  the default in `GeminiLiveClient`. Google renames/retires live-audio
  models fairly often — check the current model name in Google AI Studio
  and update the constant (or wire it to a Settings field) if connection
  setup fails.
- **Contact → phone number resolution**: `placeCall()` currently opens the
  dialer rather than resolving a spoken name to a number, since that needs
  `READ_CONTACTS` plus a contacts-provider lookup, which was left out of
  the automation service so it stays focused. Add a `ContactResolver` in
  `data/repository/` and query `ContactsContract` before dialing.
- **Gemini function-calling for automation**: today the WhatsApp/app-open/
  toggle commands are parsed locally by `CommandParser` from the live
  transcript as a fast-path. For tighter accuracy, declare these as Gemini
  *tools* in the `setup` message and act on `toolCall` messages instead
  (the `GeminiLiveClient.handleServerMessage` already has a stub for it).
- **Launcher icon / splash** — not included; add your own art.
- **Room ~30MB budget** — enforced today only by periodically summarizing
  old conversations (`ConversationRepository`); wire a WorkManager job that
  calls Gemini to summarize+prune conversations older than N days so the
  DB doesn't grow unbounded.
