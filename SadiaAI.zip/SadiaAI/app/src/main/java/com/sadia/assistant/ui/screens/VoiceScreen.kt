package com.sadia.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IconButton
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.sadia.assistant.ui.SadiaViewModel
import com.sadia.assistant.ui.components.DeveloperBadge
import com.sadia.assistant.ui.components.EdgeGlowOverlay
import com.sadia.assistant.ui.components.OrbState
import com.sadia.assistant.ui.components.SadiaOrb
import com.sadia.assistant.ui.theme.DangerRed
import com.sadia.assistant.ui.theme.MidnightBlack
import com.sadia.assistant.ui.theme.NeonBlue
import com.sadia.assistant.ui.theme.TextSecondary

@Composable
fun VoiceScreen(
    onOpenHistory: () -> Unit,
    onOpenSettings: () -> Unit,
    viewModel: SadiaViewModel = hiltViewModel()
) {
    val state by viewModel.uiState.collectAsState()
    var micOn by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf(false) }

    androidx.compose.runtime.LaunchedEffect(Unit) {
        if (state.hasApiKey) viewModel.startSession()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightBlack)
    ) {
        EdgeGlowOverlay(state = state.orbState, modifier = Modifier.fillMaxSize())

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            TopBar(onOpenHistory = onOpenHistory, onOpenSettings = onOpenSettings)

            Spacer(modifier = Modifier.weight(1f))

            DeveloperBadge()
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "সাদিয়া এআই",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(32.dp))

            SadiaOrb(amplitude = state.amplitude, state = state.orbState)

            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = statusLabel(state.orbState, state.isConnected, state.hasApiKey),
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )

            Spacer(modifier = Modifier.weight(1f))

            MicButton(
                micOn = micOn,
                enabled = state.hasApiKey,
                onToggle = {
                    micOn = !micOn
                    viewModel.toggleMic(micOn)
                }
            )
            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    state.pendingConfirmation?.let { pending ->
        AlertDialog(
            onDismissRequest = { },
            title = { Text("সাদিয়া জিজ্ঞেস করছে") },
            text = { Text(pending.promptBangla) },
            confirmButton = {
                TextButton(onClick = { viewModel.resolvePendingConfirmation(true) }) {
                    Text("হ্যাঁ, করো", color = NeonBlue)
                }
            },
            dismissButton = {
                TextButton(onClick = { viewModel.resolvePendingConfirmation(false) }) {
                    Text("না, বাদ দাও", color = DangerRed)
                }
            }
        )
    }
}

@Composable
private fun TopBar(onOpenHistory: () -> Unit, onOpenSettings: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        IconButton(onClick = onOpenHistory) {
            Icon(Icons.Filled.History, contentDescription = "কথোপকথনের ইতিহাস", tint = NeonBlue)
        }
        IconButton(onClick = onOpenSettings) {
            Icon(Icons.Filled.Settings, contentDescription = "সেটিংস", tint = NeonBlue)
        }
    }
}

@Composable
private fun MicButton(micOn: Boolean, enabled: Boolean, onToggle: () -> Unit) {
    val bg = if (micOn) MaterialTheme.colorScheme.secondary else MaterialTheme.colorScheme.primary
    Box(
        modifier = Modifier
            .size(76.dp)
            .background(if (enabled) bg else Color.DarkGray, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        IconButton(onClick = onToggle, enabled = enabled) {
            Icon(
                imageVector = if (micOn) Icons.Filled.Mic else Icons.Filled.MicOff,
                contentDescription = "মাইক্রোফোন টগল",
                tint = MidnightBlack,
                modifier = Modifier.size(32.dp)
            )
        }
    }
}

private fun statusLabel(orb: OrbState, connected: Boolean, hasApiKey: Boolean): String = when {
    !hasApiKey -> "প্রথমে সেটিংসে গিয়ে Gemini API কী যোগ করুন"
    !connected -> "সংযোগ হচ্ছে..."
    orb == OrbState.LISTENING -> "শুনছি..."
    orb == OrbState.SPEAKING -> "বলছি..."
    orb == OrbState.THINKING -> "ভাবছি..."
    else -> "মাইক চাপুন এবং কথা বলা শুরু করুন"
}
