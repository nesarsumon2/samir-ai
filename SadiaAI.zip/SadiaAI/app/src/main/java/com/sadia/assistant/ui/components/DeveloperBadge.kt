package com.sadia.assistant.ui.components

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sadia.assistant.ui.theme.NeonBlue

/** "Developed by Samir" — neon-glow credit shown on Home (Layer 1) and above Settings (Layer 3). */
@Composable
fun DeveloperBadge(modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "badgeGlow")
    val glow by infinite.animateFloat(
        initialValue = 6f,
        targetValue = 18f,
        animationSpec = infiniteRepeatable(tween(1600), RepeatMode.Reverse),
        label = "glowRadius"
    )

    Text(
        text = "Developed by Samir",
        modifier = modifier
            .shadow(elevation = glow.dp, clip = false)
            .padding(horizontal = 4.dp),
        style = TextStyle(
            color = NeonBlue,
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            letterSpacing = 1.5.sp,
            shadow = Shadow(color = NeonBlue, blurRadius = glow)
        )
    )
}
