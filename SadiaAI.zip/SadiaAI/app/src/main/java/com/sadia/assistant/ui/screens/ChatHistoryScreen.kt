package com.sadia.assistant.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IconButton
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.sadia.assistant.data.local.TaskLogEntity
import com.sadia.assistant.ui.SadiaViewModel
import com.sadia.assistant.ui.theme.DangerRed
import com.sadia.assistant.ui.theme.MidnightBlack
import com.sadia.assistant.ui.theme.NeonBlue
import com.sadia.assistant.ui.theme.NeonPurple
import com.sadia.assistant.ui.theme.SuccessGreen
import com.sadia.assistant.ui.theme.SurfaceDark
import com.sadia.assistant.ui.theme.TextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ChatHistoryScreen(onBack: () -> Unit, viewModel: SadiaViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightBlack)
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "ফিরে যান", tint = NeonBlue)
            }
            Text("চ্যাট ও টাস্ক লগ", style = MaterialTheme.typography.titleLarge)
        }

        Text(
            "কথোপকথন",
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 16.dp, bottom = 8.dp),
            color = TextSecondary
        )
        val logs by viewModel.taskLogs.collectAsState()

        LazyColumn(modifier = Modifier.fillMaxWidth().weight(1f)) {
            items(state.transcript) { line ->
                TranscriptBubble(role = line.role, text = line.text)
            }
            if (logs.isNotEmpty()) {
                item {
                    Text(
                        "অটোমেশন হিস্ট্রি",
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(top = 16.dp, bottom = 8.dp),
                        color = TextSecondary
                    )
                }
                items(logs) { log -> TaskLogCard(log) }
            }
        }
    }
}

@Composable
private fun TranscriptBubble(role: String, text: String) {
    val isUser = role == "user"
    val accent = if (isUser) NeonBlue else NeonPurple
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        Card(
            colors = CardDefaults.cardColors(containerColor = SurfaceDark),
            shape = RoundedCornerShape(14.dp)
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = if (isUser) "আপনি" else if (role == "sadia") "সাদিয়া" else "সিস্টেম",
                    style = MaterialTheme.typography.labelSmall,
                    color = accent
                )
                Text(text = text, style = MaterialTheme.typography.bodyLarge)
            }
        }
    }
}

@Composable
fun TaskLogCard(log: TaskLogEntity) {
    val fmt = remember(log.timestamp) { SimpleDateFormat("hh:mm a", Locale("bn")).format(Date(log.timestamp)) }
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(14.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth().padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(log.action, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
                Text(log.detail, style = MaterialTheme.typography.bodyLarge)
                Text(fmt, style = MaterialTheme.typography.labelSmall, color = TextSecondary)
            }
            Icon(
                imageVector = if (log.success) Icons.Filled.CheckCircle else Icons.Filled.Error,
                contentDescription = null,
                tint = if (log.success) SuccessGreen else DangerRed
            )
        }
    }
}
