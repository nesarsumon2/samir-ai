package com.sadia.assistant.accessibility

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Sadia's hands: reads the screen hierarchy, taps/types on the user's behalf,
 * launches apps by voice, and drives the WhatsApp "open chat → type → send"
 * flow. Sensitive actions (sending a message, placing a call) always route
 * through SadiaAutomationBridge.requestConfirmation() first.
 */
class SadiaAccessibilityService : AccessibilityService() {

    private val scope = CoroutineScope(Dispatchers.Main)
    private var lastRootPackage: String? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        SadiaAutomationServiceLocator.service = this
        SadiaAutomationBridge.setServiceConnected(true)
    }

    override fun onDestroy() {
        super.onDestroy()
        SadiaAutomationServiceLocator.service = null
        SadiaAutomationBridge.setServiceConnected(false)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        event?.packageName?.toString()?.let { lastRootPackage = it }
    }

    override fun onInterrupt() {}

    /** Entry point called by SadiaViewModel after it parses a voice command. */
    fun execute(command: SadiaCommand) {
        scope.launch {
            when (command) {
                is SadiaCommand.OpenApp -> openApp(command.appName)
                is SadiaCommand.SendWhatsApp -> sendWhatsApp(command)
                is SadiaCommand.CallContact -> placeCall(command)
                is SadiaCommand.ToggleSystem -> toggleSystem(command)
                SadiaCommand.ReadNotifications -> {
                    // Handled by SadiaNotificationListener; this just acks the intent.
                    SadiaAutomationBridge.reportExecuted("READ_NOTIFICATIONS", "নোটিফিকেশন পড়া শুরু হয়েছে", true)
                }
                SadiaCommand.Unknown -> {
                    SadiaAutomationBridge.reportExecuted("UNKNOWN", "কমান্ডটি বুঝতে পারিনি", false)
                }
            }
        }
    }

    private fun openApp(appName: String) {
        val pkg = CommandParser.resolvePackage(appName)
        if (pkg == null) {
            SadiaAutomationBridge.reportExecuted("OPEN_APP", "'$appName' অ্যাপটি খুঁজে পাইনি", false)
            return
        }
        val intent = packageManager.getLaunchIntentForPackage(pkg)
        if (intent != null) {
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            SadiaAutomationBridge.reportExecuted("OPEN_APP", "$appName খোলা হয়েছে", true)
        } else {
            SadiaAutomationBridge.reportExecuted("OPEN_APP", "$appName ফোনে ইনস্টল করা নেই", false)
        }
    }

    private suspend fun sendWhatsApp(cmd: SadiaCommand.SendWhatsApp) {
        val approved = SadiaAutomationBridge.requestConfirmation(
            promptBangla = "আমি ${cmd.contactName}-কে হোয়াটসঅ্যাপে লিখছি: \"${cmd.message}\" — পাঠিয়ে দেব?",
            action = cmd
        )
        if (!approved) {
            SadiaAutomationBridge.reportExecuted("WHATSAPP_SEND", "পাঠানো বাতিল করা হয়েছে", false)
            return
        }

        // Deep-link straight into the chat's compose box — far more reliable than
        // driving WhatsApp's own contact search UI across OEM skins.
        val uri = Uri.parse(
            "https://api.whatsapp.com/send?phone=&text=" + Uri.encode(cmd.message)
        )
        val intent = Intent(Intent.ACTION_VIEW, uri).apply {
            setPackage("com.whatsapp")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        runCatching { startActivity(intent) }.onFailure {
            SadiaAutomationBridge.reportExecuted("WHATSAPP_SEND", "হোয়াটসঅ্যাপ খোলা যায়নি", false)
            return
        }

        // Wait for WhatsApp's contact picker / chat list to render, then let the
        // node-search step pick the right contact and tap send.
        delay(1200)
        val root = rootInActiveWindow
        if (root != null) {
            val contactNode = findNodeContainingText(root, cmd.contactName)
            contactNode?.let { performClick(it) }
            delay(800)
            val sendBtn = rootInActiveWindow?.let { findNodeByViewId(it, "com.whatsapp:id/send") }
            if (sendBtn != null) {
                performClick(sendBtn)
                SadiaAutomationBridge.reportExecuted("WHATSAPP_SEND", "${cmd.contactName}-কে মেসেজ পাঠানো হয়েছে", true)
            } else {
                SadiaAutomationBridge.reportExecuted(
                    "WHATSAPP_SEND",
                    "চ্যাট খোলা হয়েছে, মেসেজ টাইপ করা আছে — সেন্ড বাটনটি নিজে চাপুন",
                    true
                )
            }
        }
    }

    private suspend fun placeCall(cmd: SadiaCommand.CallContact) {
        val approved = SadiaAutomationBridge.requestConfirmation(
            promptBangla = "আমি কি এখন ${cmd.contactName}-কে কল করবো?",
            action = cmd
        )
        if (!approved) {
            SadiaAutomationBridge.reportExecuted("CALL", "কল বাতিল করা হয়েছে", false)
            return
        }
        // Resolving a name to a phone number requires READ_CONTACTS + a contacts
        // lookup step (kept out of the accessibility service on purpose — see
        // ContactResolver in the repository layer for the full pipeline).
        val dialIntent = Intent(Intent.ACTION_DIAL).apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        startActivity(dialIntent)
        SadiaAutomationBridge.reportExecuted("CALL", "${cmd.contactName}-এর জন্য ডায়ালার খোলা হয়েছে", true)
    }

    private fun toggleSystem(cmd: SadiaCommand.ToggleSystem) {
        val action = when (cmd.toggle) {
            SystemToggle.WIFI -> android.provider.Settings.Panel.ACTION_WIFI
            SystemToggle.BLUETOOTH -> android.provider.Settings.ACTION_BLUETOOTH_SETTINGS
            SystemToggle.FLASHLIGHT -> null
        }
        if (cmd.toggle == SystemToggle.FLASHLIGHT) {
            runCatching {
                val cameraManager = getSystemService(CAMERA_SERVICE) as android.hardware.camera2.CameraManager
                val cameraId = cameraManager.cameraIdList.firstOrNull() ?: return
                cameraManager.setTorchMode(cameraId, cmd.turnOn)
            }
            SadiaAutomationBridge.reportExecuted(
                "TOGGLE_FLASHLIGHT",
                if (cmd.turnOn) "ফ্ল্যাশলাইট চালু করা হয়েছে" else "ফ্ল্যাশলাইট বন্ধ করা হয়েছে",
                true
            )
            return
        }
        action?.let {
            startActivity(Intent(it).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            SadiaAutomationBridge.reportExecuted("TOGGLE_SYSTEM", "সেটিংস প্যানেল খোলা হয়েছে", true)
        }
    }

    // ---- Node-tree helpers ----

    private fun performClick(node: AccessibilityNodeInfo) {
        var target: AccessibilityNodeInfo? = node
        while (target != null && !target.isClickable) {
            target = target.parent
        }
        target?.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun typeIntoFocusedField(text: String) {
        val root = rootInActiveWindow ?: return
        val editable = findFirstEditable(root) ?: return
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        editable.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }

    private fun findFirstEditable(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isEditable) return node
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                findFirstEditable(child)?.let { return it }
            }
        }
        return null
    }

    private fun findNodeContainingText(node: AccessibilityNodeInfo, text: String): AccessibilityNodeInfo? {
        if (node.text?.toString()?.contains(text, ignoreCase = true) == true) return node
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { child ->
                findNodeContainingText(child, text)?.let { return it }
            }
        }
        return null
    }

    private fun findNodeByViewId(node: AccessibilityNodeInfo, viewId: String): AccessibilityNodeInfo? {
        val matches = node.findAccessibilityNodeInfosByViewId(viewId)
        return matches?.firstOrNull()
    }

    companion object {
        private const val TAG = "SadiaAccessibility"
    }
}
