package com.sadia.assistant.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface ConversationDao {
    @Insert
    suspend fun insertConversation(conversation: ConversationEntity): Long

    @Update
    suspend fun updateConversation(conversation: ConversationEntity)

    @Query("SELECT * FROM conversations ORDER BY lastUpdatedAt DESC")
    fun observeConversations(): Flow<List<ConversationEntity>>

    @Query("SELECT * FROM conversations WHERE id = :id")
    suspend fun getConversation(id: Long): ConversationEntity?

    @Query("SELECT summary FROM conversations WHERE summary != '' ORDER BY lastUpdatedAt DESC LIMIT :limit")
    suspend fun getRecentSummaries(limit: Int = 10): List<String>
}

@Dao
interface MessageDao {
    @Insert
    suspend fun insertMessage(message: MessageEntity): Long

    @Query("SELECT * FROM messages WHERE conversationId = :conversationId ORDER BY timestamp ASC")
    fun observeMessages(conversationId: Long): Flow<List<MessageEntity>>

    @Query("SELECT * FROM messages ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentMessages(limit: Int = 20): List<MessageEntity>
}

@Dao
interface MemoryFactDao {
    @Query("SELECT * FROM memory_facts WHERE `key` = :key LIMIT 1")
    suspend fun getFact(key: String): MemoryFactEntity?

    @Query("SELECT * FROM memory_facts ORDER BY updatedAt DESC")
    fun observeAllFacts(): Flow<List<MemoryFactEntity>>

    @Insert
    suspend fun insertFact(fact: MemoryFactEntity): Long

    @Update
    suspend fun updateFact(fact: MemoryFactEntity)

    suspend fun upsertFact(key: String, value: String) {
        val existing = getFact(key)
        if (existing == null) {
            insertFact(MemoryFactEntity(key = key, value = value, updatedAt = System.currentTimeMillis()))
        } else {
            updateFact(existing.copy(value = value, updatedAt = System.currentTimeMillis()))
        }
    }
}

@Dao
interface TaskLogDao {
    @Insert
    suspend fun insertLog(log: TaskLogEntity): Long

    @Query("SELECT * FROM task_logs ORDER BY timestamp DESC LIMIT 100")
    fun observeRecentLogs(): Flow<List<TaskLogEntity>>
}
