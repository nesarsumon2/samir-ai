package com.sadia.assistant.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
    entities = [
        ConversationEntity::class,
        MessageEntity::class,
        MemoryFactEntity::class,
        TaskLogEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class SadiaDatabase : RoomDatabase() {
    abstract fun conversationDao(): ConversationDao
    abstract fun messageDao(): MessageDao
    abstract fun memoryFactDao(): MemoryFactDao
    abstract fun taskLogDao(): TaskLogDao

    companion object {
        @Volatile private var INSTANCE: SadiaDatabase? = null

        fun getInstance(context: Context): SadiaDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    SadiaDatabase::class.java,
                    "sadia_memory.db"
                )
                    // ~30MB working budget enforced by periodic summary compaction
                    // in ConversationRepository rather than a hard DB cap.
                    .fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
    }
}
