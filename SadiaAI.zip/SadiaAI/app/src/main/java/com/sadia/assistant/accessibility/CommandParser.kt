package com.sadia.assistant.accessibility

sealed class SadiaCommand {
    data class SendWhatsApp(val contactName: String, val message: String) : SadiaCommand()
    data class OpenApp(val appName: String) : SadiaCommand()
    data class CallContact(val contactName: String) : SadiaCommand()
    data class ToggleSystem(val toggle: SystemToggle, val turnOn: Boolean) : SadiaCommand()
    object ReadNotifications : SadiaCommand()
    object Unknown : SadiaCommand()
}

enum class SystemToggle { WIFI, BLUETOOTH, FLASHLIGHT }

/** Known app name → package name map for the "মুখে বললেই অ্যাপ খুলবে" feature. */
object AppRegistry {
    val PACKAGES = mapOf(
        "হোয়াটসঅ্যাপ" to "com.whatsapp",
        "whatsapp" to "com.whatsapp",
        "ফেসবুক" to "com.facebook.katana",
        "facebook" to "com.facebook.katana",
        "মেসেঞ্জার" to "com.facebook.orca",
        "messenger" to "com.facebook.orca",
        "ইউটিউব" to "com.google.android.youtube",
        "youtube" to "com.google.android.youtube",
        "ক্যামেরা" to "com.android.camera",
        "ক্রোম" to "com.android.chrome",
        "chrome" to "com.android.chrome",
        "গ্যালারি" to "com.google.android.apps.photos",
        "ইনস্টাগ্রাম" to "com.instagram.android",
        "instagram" to "com.instagram.android"
    )
}

/**
 * Rule-based Bangla command parser. The Gemini Live model itself does the
 * heavy conversational understanding; this is a fast local fallback /
 * confirmation layer so automation intents never depend on network latency
 * once Sadia has decided *what* to do (Gemini returns a structured action
 * via function-calling in the full pipeline — see GeminiLiveClient.toolCall).
 */
object CommandParser {

    private val whatsappPattern = Regex(
        "(হোয়াটসঅ্যাপ|whatsapp)[এযে]?\\s*(.+?)\\s*কে\\s*(বলো|লেখো|পাঠাও)\\s*(.+)",
        RegexOption.IGNORE_CASE
    )
    private val openAppPattern = Regex("(.+?)\\s*(খোলো|ওপেন করো|চালু করো)", RegexOption.IGNORE_CASE)
    private val callPattern = Regex("(.+?)\\s*কে\\s*(কল করো|ফোন করো)", RegexOption.IGNORE_CASE)

    fun parse(utterance: String): SadiaCommand {
        val text = utterance.trim()

        whatsappPattern.find(text)?.let { m ->
            val contact = m.groupValues[2].trim()
            val message = m.groupValues[4].trim()
            if (contact.isNotBlank() && message.isNotBlank()) {
                return SadiaCommand.SendWhatsApp(contact, message)
            }
        }

        callPattern.find(text)?.let { m ->
            return SadiaCommand.CallContact(m.groupValues[1].trim())
        }

        if (text.contains("ওয়াইফাই") || text.contains("wifi", ignoreCase = true)) {
            return SadiaCommand.ToggleSystem(SystemToggle.WIFI, turnOn = !text.contains("বন্ধ"))
        }
        if (text.contains("ব্লুটুথ") || text.contains("bluetooth", ignoreCase = true)) {
            return SadiaCommand.ToggleSystem(SystemToggle.BLUETOOTH, turnOn = !text.contains("বন্ধ"))
        }
        if (text.contains("ফ্ল্যাশ") || text.contains("টর্চ") || text.contains("flashlight", ignoreCase = true)) {
            return SadiaCommand.ToggleSystem(SystemToggle.FLASHLIGHT, turnOn = !text.contains("বন্ধ"))
        }
        if (text.contains("নোটিফিকেশন") && (text.contains("পড়ো") || text.contains("শোনাও"))) {
            return SadiaCommand.ReadNotifications
        }

        openAppPattern.find(text)?.let { m ->
            val appName = m.groupValues[1].trim()
            if (AppRegistry.PACKAGES.keys.any { appName.contains(it, ignoreCase = true) }) {
                return SadiaCommand.OpenApp(appName)
            }
        }

        return SadiaCommand.Unknown
    }

    fun resolvePackage(appName: String): String? =
        AppRegistry.PACKAGES.entries.firstOrNull { appName.contains(it.key, ignoreCase = true) }?.value
}
