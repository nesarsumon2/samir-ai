package com.sadia.assistant.accessibility

/**
 * AccessibilityService instances are owned by the system, not Hilt, so the
 * ViewModel reaches it through this lightweight locator rather than DI.
 * Set in onServiceConnected/onDestroy of SadiaAccessibilityService.
 */
object SadiaAutomationServiceLocator {
    var service: SadiaAccessibilityService? = null
}
