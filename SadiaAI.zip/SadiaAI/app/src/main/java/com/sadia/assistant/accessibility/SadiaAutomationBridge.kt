package com.sadia.assistant.accessibility

import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

data class PendingConfirmation(
    val id: Long,
    val promptBangla: String,
    val action: SadiaCommand
)

/**
 * Process-wide singleton bridging SadiaAccessibilityService (which can't easily
 * own Compose/voice state) and the rest of the app. The service posts sensitive
 * actions here and suspends on the result; SadiaViewModel asks the question
 * aloud through Gemini Live and resolves it once the user answers.
 */
object SadiaAutomationBridge {

    private val _serviceConnected = MutableStateFlow(false)
    val serviceConnected: StateFlow<Boolean> = _serviceConnected

    private val _pendingConfirmation = MutableStateFlow<PendingConfirmation?>(null)
    val pendingConfirmation: StateFlow<PendingConfirmation?> = _pendingConfirmation

    val executedActions = MutableSharedFlow<Triple<String, String, Boolean>>(extraBufferCapacity = 16) // action, detail, success

    private var pendingDeferred: CompletableDeferred<Boolean>? = null
    private var idCounter = 0L

    fun setServiceConnected(connected: Boolean) {
        _serviceConnected.value = connected
    }

    /** Called from the AccessibilityService's coroutine before executing a sensitive action. */
    suspend fun requestConfirmation(promptBangla: String, action: SadiaCommand): Boolean {
        val deferred = CompletableDeferred<Boolean>()
        pendingDeferred = deferred
        _pendingConfirmation.value = PendingConfirmation(idCounter++, promptBangla, action)
        val result = deferred.await()
        _pendingConfirmation.value = null
        return result
    }

    /** Called from SadiaViewModel once the user answers "হ্যাঁ" / "না" by voice or UI. */
    fun resolveConfirmation(approved: Boolean) {
        pendingDeferred?.complete(approved)
        pendingDeferred = null
    }

    fun reportExecuted(action: String, detail: String, success: Boolean) {
        executedActions.tryEmit(Triple(action, detail, success))
    }
}
