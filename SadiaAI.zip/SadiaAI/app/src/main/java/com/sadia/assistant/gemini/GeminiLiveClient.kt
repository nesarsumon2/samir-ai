package com.sadia.assistant.gemini

import android.util.Base64
import android.util.Log
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

sealed class GeminiLiveEvent {
    data class ModelAudioChunk(val pcm: ByteArray) : GeminiLiveEvent()
    data class ModelText(val text: String) : GeminiLiveEvent()
    data class UserTranscript(val text: String) : GeminiLiveEvent()
    object Interrupted : GeminiLiveEvent()
    object TurnComplete : GeminiLiveEvent()
    data class Error(val message: String) : GeminiLiveEvent()
    object Connected : GeminiLiveEvent()
    object Disconnected : GeminiLiveEvent()
}

/**
 * Minimal, dependency-light client for Gemini's Live (BidiGenerateContent) WebSocket API.
 * Streams 16kHz PCM16 mic audio out and receives 24kHz PCM16 model audio + transcripts back,
 * with full support for server-driven interruption (barge-in).
 *
 * Protocol reference: generativelanguage.googleapis.com BidiGenerateContent, v1beta.
 * Model name is configurable from Settings in case Google renames/retires live models.
 */
class GeminiLiveClient(
    private val apiKey: String,
    private val modelName: String = "models/gemini-2.0-flash-live-001",
    private val voiceName: String = "Kore",
    private val systemInstruction: String
) {
    private val client = OkHttpClient.Builder()
        .readTimeout(0, TimeUnit.MILLISECONDS) // long-lived socket
        .pingInterval(20, TimeUnit.SECONDS)
        .build()

    private var webSocket: WebSocket? = null

    private val _events = MutableSharedFlow<GeminiLiveEvent>(extraBufferCapacity = 64)
    val events: SharedFlow<GeminiLiveEvent> = _events

    fun connect() {
        val url = "wss://generativelanguage.googleapis.com/ws/" +
            "google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent?key=$apiKey"
        val request = Request.Builder().url(url).build()
        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: okhttp3.Response) {
                sendSetupMessage(ws)
                _events.tryEmit(GeminiLiveEvent.Connected)
            }

            override fun onMessage(ws: WebSocket, text: String) {
                handleServerMessage(text)
            }

            override fun onMessage(ws: WebSocket, bytes: ByteString) {
                handleServerMessage(bytes.utf8())
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: okhttp3.Response?) {
                Log.e("GeminiLive", "socket failure", t)
                _events.tryEmit(GeminiLiveEvent.Error(t.message ?: "connection failed"))
                _events.tryEmit(GeminiLiveEvent.Disconnected)
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                _events.tryEmit(GeminiLiveEvent.Disconnected)
            }
        })
    }

    private fun sendSetupMessage(ws: WebSocket) {
        val setup = JSONObject().apply {
            put("setup", JSONObject().apply {
                put("model", modelName)
                put("generation_config", JSONObject().apply {
                    put("response_modalities", JSONArray().put("AUDIO"))
                    put("speech_config", JSONObject().apply {
                        put("voice_config", JSONObject().apply {
                            put("prebuilt_voice_config", JSONObject().apply {
                                put("voice_name", voiceName)
                            })
                        })
                    })
                })
                put("system_instruction", JSONObject().apply {
                    put("parts", JSONArray().put(JSONObject().put("text", systemInstruction)))
                })
            })
        }
        ws.send(setup.toString())
    }

    /** Streams one mic chunk (raw PCM16 @16kHz) to the model as it's captured. */
    fun sendAudioChunk(pcm: ByteArray) {
        val b64 = Base64.encodeToString(pcm, Base64.NO_WRAP)
        val msg = JSONObject().apply {
            put("realtime_input", JSONObject().apply {
                put("media_chunks", JSONArray().put(
                    JSONObject().apply {
                        put("mime_type", "audio/pcm;rate=16000")
                        put("data", b64)
                    }
                ))
            })
        }
        webSocket?.send(msg.toString())
    }

    /** Sends a typed/text turn (used for text fallback or injected system nudges). */
    fun sendText(text: String, endOfTurn: Boolean = true) {
        val msg = JSONObject().apply {
            put("client_content", JSONObject().apply {
                put("turns", JSONArray().put(
                    JSONObject().apply {
                        put("role", "user")
                        put("parts", JSONArray().put(JSONObject().put("text", text)))
                    }
                ))
                put("turn_complete", endOfTurn)
            })
        }
        webSocket?.send(msg.toString())
    }

    private fun handleServerMessage(raw: String) {
        runCatching {
            val json = JSONObject(raw)

            json.optJSONObject("serverContent")?.let { serverContent ->
                if (serverContent.optBoolean("interrupted", false)) {
                    _events.tryEmit(GeminiLiveEvent.Interrupted)
                }

                serverContent.optJSONObject("modelTurn")?.optJSONArray("parts")?.let { parts ->
                    for (i in 0 until parts.length()) {
                        val part = parts.getJSONObject(i)
                        part.optJSONObject("inlineData")?.let { inline ->
                            val mime = inline.optString("mimeType")
                            if (mime.startsWith("audio/")) {
                                val bytes = Base64.decode(inline.optString("data"), Base64.NO_WRAP)
                                _events.tryEmit(GeminiLiveEvent.ModelAudioChunk(bytes))
                            }
                        }
                        part.optString("text", "").takeIf { it.isNotBlank() }?.let {
                            _events.tryEmit(GeminiLiveEvent.ModelText(it))
                        }
                    }
                }

                serverContent.optJSONObject("inputTranscription")?.optString("text")
                    ?.takeIf { it.isNotBlank() }
                    ?.let { _events.tryEmit(GeminiLiveEvent.UserTranscript(it)) }

                if (serverContent.optBoolean("turnComplete", false)) {
                    _events.tryEmit(GeminiLiveEvent.TurnComplete)
                }
            }

            json.optJSONObject("toolCall")?.let {
                // Future hook: Gemini function-calling for device automation intents.
                Log.d("GeminiLive", "toolCall received: $it")
            }
        }.onFailure {
            Log.e("GeminiLive", "failed to parse server message", it)
        }
    }

    fun disconnect() {
        webSocket?.close(1000, "client closed")
        webSocket = null
    }
}
