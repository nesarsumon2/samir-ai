package com.sadia.assistant.gemini

import android.annotation.SuppressLint
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.sqrt

/**
 * Captures mic audio at 16kHz PCM16 mono (Gemini Live input format) and plays
 * back model audio at 24kHz PCM16 mono (Gemini Live output format).
 * Exposes live RMS amplitude for both directions so the UI orb can react.
 */
class AudioEngine {

    companion object {
        const val INPUT_SAMPLE_RATE = 16000
        const val OUTPUT_SAMPLE_RATE = 24000
    }

    private var audioRecord: AudioRecord? = null
    private var audioTrack: AudioTrack? = null
    private var recordJob: kotlinx.coroutines.Job? = null
    private val scope = CoroutineScope(Dispatchers.Default)

    private val _micAmplitude = MutableStateFlow(0f)
    val micAmplitude: StateFlow<Float> = _micAmplitude

    private val _playbackAmplitude = MutableStateFlow(0f)
    val playbackAmplitude: StateFlow<Float> = _playbackAmplitude

    private val _isRecording = MutableStateFlow(false)
    val isRecording: StateFlow<Boolean> = _isRecording

    @SuppressLint("MissingPermission") // caller must have verified RECORD_AUDIO at runtime
    fun startCapture(onPcmChunk: (ByteArray) -> Unit) {
        val minBuf = AudioRecord.getMinBufferSize(
            INPUT_SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val bufferSize = minBuf * 2
        val record = AudioRecord(
            MediaRecorder.AudioSource.VOICE_COMMUNICATION,
            INPUT_SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT,
            bufferSize
        )
        audioRecord = record
        record.startRecording()
        _isRecording.value = true

        recordJob = scope.launch {
            val chunk = ByteArray(1280) // 40ms @16kHz/16-bit mono
            while (isActive && _isRecording.value) {
                val read = record.read(chunk, 0, chunk.size)
                if (read > 0) {
                    _micAmplitude.value = rms(chunk, read)
                    onPcmChunk(chunk.copyOf(read))
                }
            }
        }
    }

    fun stopCapture() {
        _isRecording.value = false
        recordJob?.cancel()
        audioRecord?.apply {
            stop()
            release()
        }
        audioRecord = null
        _micAmplitude.value = 0f
    }

    /** Lazily creates the playback track; call writePlaybackChunk() for each audio part received. */
    private fun ensureTrack(): AudioTrack {
        audioTrack?.let { return it }
        val minBuf = AudioTrack.getMinBufferSize(
            OUTPUT_SAMPLE_RATE,
            AudioFormat.CHANNEL_OUT_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        val track = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(OUTPUT_SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .build()
            )
            .setBufferSizeInBytes(minBuf * 2)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .build()
        track.play()
        audioTrack = track
        return track
    }

    fun writePlaybackChunk(pcm: ByteArray) {
        val track = ensureTrack()
        _playbackAmplitude.value = rms(pcm, pcm.size)
        track.write(pcm, 0, pcm.size)
    }

    /** Barge-in: immediately flush queued model audio so Sadia stops talking mid-word. */
    fun interruptPlayback() {
        audioTrack?.apply {
            pause()
            flush()
            play()
        }
        _playbackAmplitude.value = 0f
    }

    fun release() {
        stopCapture()
        audioTrack?.apply {
            stop()
            release()
        }
        audioTrack = null
    }

    private fun rms(buffer: ByteArray, length: Int): Float {
        if (length <= 0) return 0f
        var sum = 0.0
        var i = 0
        while (i + 1 < length) {
            val sample = ((buffer[i + 1].toInt() shl 8) or (buffer[i].toInt() and 0xFF)).toShort()
            sum += (sample * sample).toDouble()
            i += 2
        }
        val samples = length / 2
        if (samples == 0) return 0f
        val rmsVal = sqrt(sum / samples) / 32768.0
        return (rmsVal.toFloat() * 3.5f).coerceIn(0f, 1f) // perceptual boost for visible orb reaction
    }
}
