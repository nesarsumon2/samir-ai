package com.sadia.assistant.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import com.sadia.assistant.ui.theme.NeonBlue
import com.sadia.assistant.ui.theme.NeonPink
import com.sadia.assistant.ui.theme.NeonPurple

@Composable
fun EdgeGlowOverlay(state: OrbState, modifier: Modifier = Modifier) {
    val color by animateColorAsState(
        targetValue = when (state) {
            OrbState.IDLE -> Color.Transparent
            OrbState.LISTENING -> NeonBlue
            OrbState.SPEAKING -> NeonPurple
            OrbState.THINKING -> NeonPink
        },
        animationSpec = tween(400),
        label = "edgeColor"
    )
    val strokeWidth by animateFloatAsState(
        targetValue = if (state == OrbState.IDLE) 0f else 14f,
        animationSpec = tween(400),
        label = "edgeWidth"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        if (strokeWidth <= 0f) return@Canvas
        drawRect(
            brush = Brush.radialGradient(
                colors = listOf(color.copy(alpha = 0.55f), Color.Transparent),
                radius = size.maxDimension
            ),
            style = Stroke(width = strokeWidth)
        )
    }
}
