package com.sadia.assistant.data.repository

import com.sadia.assistant.data.local.ConversationDao
import com.sadia.assistant.data.local.ConversationEntity
import com.sadia.assistant.data.local.MemoryFactDao
import com.sadia.assistant.data.local.MessageDao
import com.sadia.assistant.data.local.MessageEntity
import com.sadia.assistant.data.local.TaskLogDao
import com.sadia.assistant.data.local.TaskLogEntity
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Long-term context memory: persists every turn, and builds the compact
 * "what Sadia remembers" block that gets injected into the Gemini Live
 * session's system instruction at connect time.
 */
@Singleton
class ConversationRepository @Inject constructor(
    private val conversationDao: ConversationDao,
    private val messageDao: MessageDao,
    private val memoryFactDao: MemoryFactDao,
    private val taskLogDao: TaskLogDao
) {
    suspend fun startConversation(title: String = "নতুন কথোপকথন"): Long {
        val now = System.currentTimeMillis()
        return conversationDao.insertConversation(
            ConversationEntity(startedAt = now, lastUpdatedAt = now, title = title)
        )
    }

    suspend fun appendMessage(conversationId: Long, role: String, text: String) {
        messageDao.insertMessage(
            MessageEntity(
                conversationId = conversationId,
                role = role,
                text = text,
                timestamp = System.currentTimeMillis()
            )
        )
        conversationDao.getConversation(conversationId)?.let {
            conversationDao.updateConversation(it.copy(lastUpdatedAt = System.currentTimeMillis()))
        }
    }

    fun observeMessages(conversationId: Long): Flow<List<MessageEntity>> =
        messageDao.observeMessages(conversationId)

    fun observeConversations(): Flow<List<ConversationEntity>> =
        conversationDao.observeConversations()

    fun observeTaskLogs(): Flow<List<TaskLogEntity>> =
        taskLogDao.observeRecentLogs()

    suspend fun logTask(action: String, detail: String, success: Boolean) {
        taskLogDao.insertLog(
            TaskLogEntity(
                timestamp = System.currentTimeMillis(),
                action = action,
                detail = detail,
                success = success
            )
        )
    }

    suspend fun rememberFact(key: String, value: String) = memoryFactDao.upsertFact(key, value)

    suspend fun recallFact(key: String): String? = memoryFactDao.getFact(key)?.value

    /** Builds the Bangla memory digest injected into every new Gemini Live session. */
    suspend fun buildMemoryContext(): String {
        val summaries = conversationDao.getRecentSummaries(limit = 8)
        val recent = messageDao.getRecentMessages(limit = 12)
        if (summaries.isEmpty() && recent.isEmpty()) return ""

        val sb = StringBuilder()
        if (summaries.isNotEmpty()) {
            sb.appendLine("পূর্ববর্তী কথোপকথনের সারসংক্ষেপ:")
            summaries.forEach { sb.appendLine("- $it") }
        }
        if (recent.isNotEmpty()) {
            sb.appendLine("সাম্প্রতিক কথোপকথনের অংশ:")
            recent.takeLast(8).forEach { sb.appendLine("${it.role}: ${it.text}") }
        }
        return sb.toString()
    }
}
