package com.sadia.assistant.ui.theme

import androidx.compose.ui.graphics.Color

// Deep midnight black background family
val MidnightBlack = Color(0xFF000000)
val DeepCharcoal = Color(0xFF0A0A12)
val SurfaceDark = Color(0xFF101018)

// Neon accents
val NeonBlue = Color(0xFF00E5FF)
val NeonBlueDim = Color(0xFF0096C7)
val NeonPurple = Color(0xFFB026FF)
val NeonPurpleDim = Color(0xFF7B2CBF)
val NeonPink = Color(0xFFFF2EC4)

val TextPrimary = Color(0xFFF2F2FF)
val TextSecondary = Color(0xFFA0A0C0)

val SuccessGreen = Color(0xFF39FF88)
val DangerRed = Color(0xFFFF3860)
