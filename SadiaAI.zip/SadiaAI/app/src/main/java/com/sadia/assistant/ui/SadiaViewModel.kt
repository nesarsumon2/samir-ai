package com.sadia.assistant.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sadia.assistant.accessibility.CommandParser
import com.sadia.assistant.accessibility.PendingConfirmation
import com.sadia.assistant.accessibility.SadiaAutomationBridge
import com.sadia.assistant.data.prefs.SecurePrefs
import com.sadia.assistant.data.repository.ConversationRepository
import com.sadia.assistant.gemini.AudioEngine
import com.sadia.assistant.gemini.GeminiLiveClient
import com.sadia.assistant.gemini.GeminiLiveEvent
import com.sadia.assistant.ui.components.OrbState
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import javax.inject.Inject

private const val SADIA_PERSONA = """
তুমি সাদিয়া — একজন মিষ্টি, বিনম্র ও প্রফেশনাল বাংলাদেশি এআই সহকারী।
তুমি সবসময় বিশুদ্ধ, স্বাভাবিক কথ্য বাংলায় কথা বলবে। তুমি ব্যবহারকারীর ফোন
নিয়ন্ত্রণ করতে পারো — অ্যাপ খোলা, হোয়াটসঅ্যাপে মেসেজ পাঠানো, কল করা, এবং
সিস্টেম সেটিংস পরিবর্তন করা। গুরুত্বপূর্ণ কাজ (মেসেজ পাঠানো, কল করা) করার
আগে সবসময় ব্যবহারকারীর কাছে মুখে নিশ্চিত হয়ে নেবে। সংক্ষিপ্ত, স্বাভাবিক
ও উষ্ণ উত্তর দেবে, রোবটিক শোনাবে না।
"""

data class SadiaUiState(
    val orbState: OrbState = OrbState.IDLE,
    val amplitude: Float = 0f,
    val isConnected: Boolean = false,
    val transcript: List<TranscriptLine> = emptyList(),
    val pendingConfirmation: PendingConfirmation? = null,
    val hasApiKey: Boolean = false
)

data class TranscriptLine(val role: String, val text: String)

@HiltViewModel
class SadiaViewModel @Inject constructor(
    private val securePrefs: SecurePrefs,
    private val conversationRepo: ConversationRepository
) : ViewModel() {

    private val audioEngine = AudioEngine()
    private var geminiClient: GeminiLiveClient? = null
    private var conversationId: Long = 0L

    private val _orbState = MutableStateFlow(OrbState.IDLE)
    private val _isConnected = MutableStateFlow(false)
    private val _transcript = MutableStateFlow<List<TranscriptLine>>(emptyList())

    val uiState: StateFlow<SadiaUiState> = combine(
        _orbState,
        audioEngine.micAmplitude,
        audioEngine.playbackAmplitude,
        _isConnected,
        _transcript,
        SadiaAutomationBridge.pendingConfirmation
    ) { values ->
        @Suppress("UNCHECKED_CAST")
        val orbState = values[0] as OrbState
        val micAmp = values[1] as Float
        val playAmp = values[2] as Float
        val connected = values[3] as Boolean
        val transcript = values[4] as List<TranscriptLine>
        val pending = values[5] as PendingConfirmation?
        SadiaUiState(
            orbState = orbState,
            amplitude = maxOf(micAmp, playAmp),
            isConnected = connected,
            transcript = transcript,
            pendingConfirmation = pending,
            hasApiKey = securePrefs.hasApiKey()
        )
    }.stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000), SadiaUiState())

    val taskLogs = conversationRepo.observeTaskLogs()
        .stateIn(viewModelScope, kotlinx.coroutines.flow.SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            conversationId = conversationRepo.startConversation()
        }
        observeAutomationEvents()
    }

    fun startSession() {
        val apiKey = securePrefs.geminiApiKey
        if (apiKey.isNullOrBlank()) return

        viewModelScope.launch {
            val memory = conversationRepo.buildMemoryContext()
            val fullInstruction = if (memory.isBlank()) SADIA_PERSONA else "$SADIA_PERSONA\n\n$memory"

            val client = GeminiLiveClient(
                apiKey = apiKey,
                voiceName = securePrefs.voiceName,
                systemInstruction = fullInstruction
            )
            geminiClient = client
            observeGeminiEvents(client)
            client.connect()
        }
    }

    fun stopSession() {
        audioEngine.stopCapture()
        geminiClient?.disconnect()
        geminiClient = null
        _isConnected.value = false
        _orbState.value = OrbState.IDLE
    }

    fun toggleMic(enabled: Boolean) {
        if (enabled) {
            _orbState.value = OrbState.LISTENING
            audioEngine.startCapture { pcm -> geminiClient?.sendAudioChunk(pcm) }
        } else {
            audioEngine.stopCapture()
            _orbState.value = OrbState.IDLE
        }
    }

    fun resolvePendingConfirmation(approved: Boolean) {
        SadiaAutomationBridge.resolveConfirmation(approved)
    }

    private fun observeGeminiEvents(client: GeminiLiveClient) {
        viewModelScope.launch {
            client.events.collect { event ->
                when (event) {
                    GeminiLiveEvent.Connected -> _isConnected.value = true
                    GeminiLiveEvent.Disconnected -> _isConnected.value = false
                    is GeminiLiveEvent.ModelAudioChunk -> {
                        _orbState.value = OrbState.SPEAKING
                        audioEngine.writePlaybackChunk(event.pcm)
                    }
                    is GeminiLiveEvent.ModelText -> {
                        appendTranscript("sadia", event.text)
                    }
                    is GeminiLiveEvent.UserTranscript -> {
                        appendTranscript("user", event.text)
                        maybeRunAutomation(event.text)
                    }
                    GeminiLiveEvent.Interrupted -> {
                        audioEngine.interruptPlayback()
                        _orbState.value = OrbState.LISTENING
                    }
                    GeminiLiveEvent.TurnComplete -> {
                        _orbState.value = OrbState.LISTENING
                    }
                    is GeminiLiveEvent.Error -> {
                        appendTranscript("system", "সংযোগ সমস্যা: ${event.message}")
                    }
                }
            }
        }
    }

    /** Local fast-path: in parallel with Gemini's own reasoning, try to detect a
     *  direct device-automation command so action latency doesn't depend on a
     *  full model round trip for simple, unambiguous requests. */
    private fun maybeRunAutomation(utterance: String) {
        val command = CommandParser.parse(utterance)
        if (command !is com.sadia.assistant.accessibility.SadiaCommand.Unknown) {
            // Dispatched via the automation bridge rather than a direct service
            // reference, since the service is a separate Android component.
            SadiaAutomationServiceLocator.service?.execute(command)
        }
    }

    private fun observeAutomationEvents() {
        viewModelScope.launch {
            SadiaAutomationBridge.executedActions.collect { (action, detail, success) ->
                conversationRepo.logTask(action, detail, success)
                appendTranscript("system", detail)
            }
        }
    }

    private fun appendTranscript(role: String, text: String) {
        _transcript.value = _transcript.value + TranscriptLine(role, text)
        viewModelScope.launch { conversationRepo.appendMessage(conversationId, role, text) }
    }

    override fun onCleared() {
        super.onCleared()
        audioEngine.release()
        geminiClient?.disconnect()
    }
}
