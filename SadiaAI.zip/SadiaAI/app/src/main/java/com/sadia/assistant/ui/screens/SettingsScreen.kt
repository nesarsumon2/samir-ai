package com.sadia.assistant.ui.screens

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IconButton
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.sadia.assistant.accessibility.SadiaAutomationBridge
import com.sadia.assistant.data.prefs.SecurePrefs
import com.sadia.assistant.ui.components.DeveloperBadge
import com.sadia.assistant.ui.theme.DangerRed
import com.sadia.assistant.ui.theme.MidnightBlack
import com.sadia.assistant.ui.theme.NeonBlue
import com.sadia.assistant.ui.theme.NeonPurple
import com.sadia.assistant.ui.theme.SuccessGreen
import com.sadia.assistant.ui.theme.SurfaceDark
import com.sadia.assistant.ui.theme.TextSecondary

private val VOICE_OPTIONS = listOf("Kore", "Puck", "Charon", "Fenrir", "Aoede")

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val securePrefs = remember { SecurePrefs(context) }
    val serviceConnected by SadiaAutomationBridge.serviceConnected.collectAsState()

    var apiKey by remember { mutableStateOf(securePrefs.geminiApiKey ?: "") }
    var voiceName by remember { mutableStateOf(securePrefs.voiceName) }
    var speechRate by remember { mutableStateOf(securePrefs.speechRate) }
    var confirmSensitive by remember { mutableStateOf(securePrefs.requireConfirmationForSensitiveActions) }
    var savedFlash by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MidnightBlack)
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "ফিরে যান", tint = NeonBlue)
            }
            Text("সেটিংস", style = MaterialTheme.typography.titleLarge)
        }

        Spacer(Modifier.height(8.dp))
        DeveloperBadge()
        Spacer(Modifier.height(20.dp))

        SectionCard(title = "Gemini API কী") {
            Text(
                "আপনার নিজস্ব Gemini API কী এখানে দিন। এটি শুধুমাত্র আপনার ফোনে এনক্রিপ্টেড অবস্থায় সংরক্ষিত থাকবে।",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = apiKey,
                onValueChange = { apiKey = it },
                label = { Text("API Key") },
                visualTransformation = PasswordVisualTransformation(),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Button(onClick = {
                    securePrefs.geminiApiKey = apiKey.trim()
                    savedFlash = true
                }) { Text("সেভ করুন") }
                if (savedFlash) {
                    Spacer(Modifier.width(12.dp))
                    Text("সংরক্ষিত হয়েছে ✓", color = SuccessGreen, style = MaterialTheme.typography.bodyMedium)
                }
            }
        }

        SectionCard(title = "ভয়েস ও কথার গতি") {
            Text("ভয়েস নির্বাচন করুন", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            Row(modifier = Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                VOICE_OPTIONS.forEach { v ->
                    VoiceChip(
                        label = v,
                        selected = v == voiceName,
                        onClick = {
                            voiceName = v
                            securePrefs.voiceName = v
                        }
                    )
                }
            }
            Spacer(Modifier.height(16.dp))
            Text("কথার গতি: ${"%.1f".format(speechRate)}x", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            Slider(
                value = speechRate,
                onValueChange = {
                    speechRate = it
                    securePrefs.speechRate = it
                },
                valueRange = 0.5f..1.5f
            )
        }

        SectionCard(title = "নিরাপত্তা") {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("গুরুত্বপূর্ণ কাজের আগে নিশ্চিত হওয়া", style = MaterialTheme.typography.bodyLarge)
                    Text(
                        "মেসেজ পাঠানো বা কল করার আগে সাদিয়া মুখে জিজ্ঞেস করবে",
                        style = MaterialTheme.typography.labelSmall,
                        color = TextSecondary
                    )
                }
                Switch(
                    checked = confirmSensitive,
                    onCheckedChange = {
                        confirmSensitive = it
                        securePrefs.requireConfirmationForSensitiveActions = it
                    }
                )
            }
        }

        SectionCard(title = "পারমিশন উইজার্ড") {
            PermissionStep(
                label = "মাইক্রোফোন",
                granted = hasMicPermission(context),
                onFix = { context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                    data = android.net.Uri.fromParts("package", context.packageName, null)
                }) }
            )
            PermissionStep(
                label = "অ্যাক্সেসিবিলিটি সার্ভিস (ফোন নিয়ন্ত্রণের জন্য)",
                granted = serviceConnected,
                onFix = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            )
            PermissionStep(
                label = "নোটিফিকেশন অ্যাক্সেস",
                granted = isNotificationListenerEnabled(context),
                onFix = { context.startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
            )
        }

        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun SectionCard(title: String, content: @Composable () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.titleLarge, color = NeonPurple)
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
private fun VoiceChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        colors = CardDefaults.cardColors(
            containerColor = if (selected) NeonBlue else MidnightBlack
        ),
        shape = RoundedCornerShape(50)
    ) {
        Text(
            label,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
            color = if (selected) MidnightBlack else TextSecondary
        )
    }
}

@Composable
private fun PermissionStep(label: String, granted: Boolean, onFix: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = if (granted) Icons.Filled.CheckCircle else Icons.Filled.RadioButtonUnchecked,
                contentDescription = null,
                tint = if (granted) SuccessGreen else DangerRed
            )
            Spacer(Modifier.width(8.dp))
            Text(label, style = MaterialTheme.typography.bodyLarge)
        }
        if (!granted) {
            Button(onClick = onFix) { Text("চালু করুন") }
        }
    }
}

private fun hasMicPermission(context: android.content.Context): Boolean =
    androidx.core.content.ContextCompat.checkSelfPermission(
        context, android.Manifest.permission.RECORD_AUDIO
    ) == android.content.pm.PackageManager.PERMISSION_GRANTED

private fun isNotificationListenerEnabled(context: android.content.Context): Boolean {
    val enabledListeners = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners")
    return enabledListeners?.contains(context.packageName) == true
}

