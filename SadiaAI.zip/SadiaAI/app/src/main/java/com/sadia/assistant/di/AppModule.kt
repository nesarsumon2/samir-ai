package com.sadia.assistant.di

import android.content.Context
import com.sadia.assistant.data.local.SadiaDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object AppModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): SadiaDatabase =
        SadiaDatabase.getInstance(context)

    @Provides
    fun provideConversationDao(db: SadiaDatabase) = db.conversationDao()

    @Provides
    fun provideMessageDao(db: SadiaDatabase) = db.messageDao()

    @Provides
    fun provideMemoryFactDao(db: SadiaDatabase) = db.memoryFactDao()

    @Provides
    fun provideTaskLogDao(db: SadiaDatabase) = db.taskLogDao()
}
