package com.sadia.assistant.accessibility

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import kotlinx.coroutines.flow.MutableSharedFlow

data class IncomingNotification(val appLabel: String, val title: String, val text: String)

/**
 * Surfaces new notifications to SadiaViewModel, which decides whether to read
 * them aloud based on the user's "নোটিফিকেশন পড়ে শোনাও" preference.
 */
class SadiaNotificationListener : NotificationListenerService() {

    override fun onNotificationPosted(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras
        val title = extras.getCharSequence("android.title")?.toString().orEmpty()
        val text = extras.getCharSequence("android.text")?.toString().orEmpty()
        if (title.isBlank() && text.isBlank()) return

        notificationStream.tryEmit(
            IncomingNotification(
                appLabel = sbn.packageName,
                title = title,
                text = text
            )
        )
    }

    companion object {
        val notificationStream = MutableSharedFlow<IncomingNotification>(extraBufferCapacity = 32)
    }
}
