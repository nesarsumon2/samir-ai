package com.sadia.assistant.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.unit.dp
import com.sadia.assistant.ui.theme.NeonBlue
import com.sadia.assistant.ui.theme.NeonPurple
import com.sadia.assistant.ui.theme.NeonPink
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * SadiaOrb — the central voice orb.
 *
 * @param amplitude 0f..1f, live mic/output RMS level. Drives glow radius, ripple
 *                  strength and the ring jitter so the orb visibly reacts to speech.
 * @param state     idle | listening | speaking | thinking — controls palette + motion speed.
 */
enum class OrbState { IDLE, LISTENING, SPEAKING, THINKING }

@Composable
fun SadiaOrb(
    amplitude: Float,
    state: OrbState,
    modifier: Modifier = Modifier
) {
    val infinite = rememberInfiniteTransition(label = "orb")

    val baseRotation by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (state == OrbState.IDLE) 20000 else 6000, easing = LinearEasing)
        ),
        label = "rotation"
    )

    val pulse by infinite.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.06f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse"
    )

    val rippleProgress by infinite.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = LinearEasing)
        ),
        label = "ripple"
    )

    val (colorA, colorB) = when (state) {
        OrbState.IDLE -> NeonBlue to NeonPurple
        OrbState.LISTENING -> NeonBlue to Color(0xFF00FFC6)
        OrbState.SPEAKING -> NeonPurple to NeonPink
        OrbState.THINKING -> NeonPink to NeonBlue
    }

    val clampedAmp = amplitude.coerceIn(0f, 1f)

    Canvas(modifier = modifier.size(260.dp)) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val baseRadius = size.minDimension / 2f * 0.55f * pulse * (1f + clampedAmp * 0.25f)

        drawOuterRipples(center, baseRadius, rippleProgress, clampedAmp, colorA, colorB)
        drawCoreOrb(center, baseRadius, baseRotation, clampedAmp, colorA, colorB)
        drawJitterParticles(center, baseRadius, baseRotation, clampedAmp, colorA)
    }
}

private fun DrawScope.drawOuterRipples(
    center: Offset,
    baseRadius: Float,
    progress: Float,
    amplitude: Float,
    colorA: Color,
    colorB: Color
) {
    val ringCount = 3
    for (i in 0 until ringCount) {
        val p = (progress + i / ringCount.toFloat()) % 1f
        val radius = baseRadius * (1f + p * (1.2f + amplitude))
        val alpha = (1f - p) * 0.35f * (0.4f + amplitude)
        drawCircle(
            color = (if (i % 2 == 0) colorA else colorB).copy(alpha = alpha.coerceIn(0f, 1f)),
            radius = radius,
            center = center,
            style = androidx.compose.ui.graphics.drawscope.Stroke(width = 2.5f + amplitude * 3f)
        )
    }
}

private fun DrawScope.drawCoreOrb(
    center: Offset,
    radius: Float,
    rotation: Float,
    amplitude: Float,
    colorA: Color,
    colorB: Color
) {
    // Outer soft glow halo
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(colorA.copy(alpha = 0.55f), colorB.copy(alpha = 0.25f), Color.Transparent),
            center = center,
            radius = radius * 2.2f
        ),
        radius = radius * 2.2f,
        center = center,
        blendMode = BlendMode.Plus
    )

    // Mid sphere — gives the fake-3D shaded look via offset highlight gradient
    val highlightOffset = Offset(
        center.x - radius * 0.3f,
        center.y - radius * 0.35f
    )
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(
                Color.White.copy(alpha = 0.9f),
                colorA.copy(alpha = 0.9f),
                colorB.copy(alpha = 0.95f),
                Color.Black.copy(alpha = 0.55f)
            ),
            center = highlightOffset,
            radius = radius * 1.6f
        ),
        radius = radius,
        center = center
    )

    // Rotating energy arcs across the surface for "alive" feel
    val arcCount = 4
    for (i in 0 until arcCount) {
        val angle = Math.toRadians((rotation + i * (360f / arcCount)).toDouble())
        val r = radius * 0.82f
        val x = center.x + (r * cos(angle)).toFloat()
        val y = center.y + (r * sin(angle)).toFloat()
        drawCircle(
            color = Color.White.copy(alpha = 0.25f + amplitude * 0.3f),
            radius = 3f + amplitude * 6f,
            center = Offset(x, y)
        )
    }
}

private fun DrawScope.drawJitterParticles(
    center: Offset,
    radius: Float,
    rotation: Float,
    amplitude: Float,
    color: Color
) {
    if (amplitude < 0.05f) return
    val rng = Random(rotation.toInt())
    repeat(6) {
        val angle = Math.toRadians(rng.nextInt(0, 360).toDouble())
        val dist = radius * (1.1f + amplitude * 0.6f) + rng.nextInt(0, 10)
        val x = center.x + (dist * cos(angle)).toFloat()
        val y = center.y + (dist * sin(angle)).toFloat()
        drawCircle(
            color = color.copy(alpha = 0.6f * amplitude),
            radius = 1.5f + amplitude * 3f,
            center = Offset(x, y)
        )
    }
}
