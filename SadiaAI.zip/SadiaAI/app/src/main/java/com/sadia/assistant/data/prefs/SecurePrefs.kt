package com.sadia.assistant.data.prefs

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SecurePrefs @Inject constructor(
    @ApplicationContext context: Context
) {
    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "sadia_secure_prefs",
        masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    var geminiApiKey: String?
        get() = prefs.getString(KEY_API_KEY, null)
        set(value) = prefs.edit().putString(KEY_API_KEY, value).apply()

    var voiceName: String
        get() = prefs.getString(KEY_VOICE_NAME, "Kore") ?: "Kore"
        set(value) = prefs.edit().putString(KEY_VOICE_NAME, value).apply()

    var speechRate: Float
        get() = prefs.getFloat(KEY_SPEECH_RATE, 1.0f)
        set(value) = prefs.edit().putFloat(KEY_SPEECH_RATE, value).apply()

    var requireConfirmationForSensitiveActions: Boolean
        get() = prefs.getBoolean(KEY_CONFIRM_SENSITIVE, true)
        set(value) = prefs.edit().putBoolean(KEY_CONFIRM_SENSITIVE, value).apply()

    var onboardingComplete: Boolean
        get() = prefs.getBoolean(KEY_ONBOARDING_DONE, false)
        set(value) = prefs.edit().putBoolean(KEY_ONBOARDING_DONE, value).apply()

    fun hasApiKey(): Boolean = !geminiApiKey.isNullOrBlank()

    fun clearApiKey() = prefs.edit().remove(KEY_API_KEY).apply()

    companion object {
        private const val KEY_API_KEY = "gemini_api_key"
        private const val KEY_VOICE_NAME = "voice_name"
        private const val KEY_SPEECH_RATE = "speech_rate"
        private const val KEY_CONFIRM_SENSITIVE = "confirm_sensitive_actions"
        private const val KEY_ONBOARDING_DONE = "onboarding_complete"
    }
}
