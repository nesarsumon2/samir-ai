package com.sadia.assistant.ui.navigation

import android.Manifest
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import com.sadia.assistant.ui.components.DeveloperBadge
import com.sadia.assistant.ui.screens.ChatHistoryScreen
import com.sadia.assistant.ui.screens.SettingsScreen
import com.sadia.assistant.ui.screens.VoiceScreen
import com.sadia.assistant.ui.theme.MidnightBlack
import com.sadia.assistant.ui.theme.NeonBlue
import com.sadia.assistant.ui.theme.TextSecondary

private object Routes {
    const val VOICE = "voice"
    const val HISTORY = "history"
    const val SETTINGS = "settings"
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun SadiaNavHost() {
    val micPermission = rememberPermissionState(Manifest.permission.RECORD_AUDIO)

    if (!micPermission.status.isGranted) {
        MicPermissionGate(onRequest = { micPermission.launchPermissionRequest() })
        return
    }

    val navController: NavHostController = rememberNavController()
    NavHost(navController = navController, startDestination = Routes.VOICE) {
        composable(Routes.VOICE) {
            VoiceScreen(
                onOpenHistory = { navController.navigate(Routes.HISTORY) },
                onOpenSettings = { navController.navigate(Routes.SETTINGS) }
            )
        }
        composable(Routes.HISTORY) {
            ChatHistoryScreen(onBack = { navController.popBackStack() })
        }
        composable(Routes.SETTINGS) {
            SettingsScreen(onBack = { navController.popBackStack() })
        }
    }
}

@Composable
private fun MicPermissionGate(onRequest: () -> Unit) {
    LaunchedEffect(Unit) { onRequest() }
    Box(
        modifier = Modifier.fillMaxSize().background(MidnightBlack),
        contentAlignment = Alignment.Center
    ) {
        Column(
            modifier = Modifier.padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            DeveloperBadge()
            Spacer(Modifier.height(24.dp))
            Text(
                "সাদিয়ার সাথে কথা বলতে মাইক্রোফোন অনুমতি প্রয়োজন",
                style = MaterialTheme.typography.titleLarge,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(Modifier.height(8.dp))
            Text(
                "এই অনুমতি ছাড়া সাদিয়া আপনার কথা শুনতে পারবে না।",
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary,
                textAlign = androidx.compose.ui.text.style.TextAlign.Center
            )
            Spacer(Modifier.height(24.dp))
            Button(onClick = onRequest) { Text("অনুমতি দিন") }
        }
    }
}
