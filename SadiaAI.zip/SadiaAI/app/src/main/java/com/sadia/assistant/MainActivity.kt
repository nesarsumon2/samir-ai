package com.sadia.assistant

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.sadia.assistant.ui.navigation.SadiaNavHost
import com.sadia.assistant.ui.theme.SadiaAITheme
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            SadiaAITheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    SadiaNavHost()
                }
            }
        }
    }
}
