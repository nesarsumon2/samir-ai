package com.sadia.assistant.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/** One conversation session. Summary is regenerated periodically so long-term
 *  memory stays cheap to load into the Gemini Live system prompt. */
@Entity(tableName = "conversations")
data class ConversationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val startedAt: Long,
    val lastUpdatedAt: Long,
    val title: String,
    val summary: String = ""
)

@Entity(tableName = "messages")
data class MessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val conversationId: Long,
    val role: String,       // "user" | "sadia" | "system"
    val text: String,
    val timestamp: Long
)

/** Facts Sadia has learned about the user (name, preferences, people) —
 *  recalled across every future conversation regardless of which session. */
@Entity(tableName = "memory_facts")
data class MemoryFactEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val key: String,        // e.g. "user_name", "contact:রাকিব"
    val value: String,
    val updatedAt: Long
)

/** Log of automation actions Sadia performed on the device — shown in the
 *  Chat & Task Log screen (Layer 2). */
@Entity(tableName = "task_logs")
data class TaskLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val action: String,     // e.g. "WHATSAPP_SEND", "OPEN_APP", "CALL"
    val detail: String,     // human-readable Bangla description
    val success: Boolean
)
