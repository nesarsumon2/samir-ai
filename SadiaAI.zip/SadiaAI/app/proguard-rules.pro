# Keep Room entities/DAOs
-keep class com.sadia.assistant.data.local.** { *; }

# Keep org.json classes used for raw Gemini Live protocol parsing
-keep class org.json.** { *; }

# OkHttp / okio
-dontwarn okhttp3.**
-dontwarn okio.**

# Hilt
-keep class dagger.hilt.** { *; }
-keep class javax.inject.** { *; }
