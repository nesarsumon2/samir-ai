#!/data/data/com.termux/files/usr/bin/bash
# সাদিয়া এআই — Termux এক-ক্লিক বিল্ড স্ক্রিপ্ট
# চালানোর নিয়ম (Termux-এ):
#   cd SadiaAI
#   bash termux_build.sh
set -e

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
SDK_DIR="$HOME/android-sdk"
CMDLINE_VER="11076708"   # cmdline-tools build ব্যবহৃত হচ্ছে

echo "========================================"
echo " সাদিয়া এআই — Termux বিল্ড শুরু হচ্ছে"
echo "========================================"

echo "[১/৭] Termux প্যাকেজ আপডেট ও প্রয়োজনীয় টুল ইনস্টল হচ্ছে..."
pkg update -y >/dev/null 2>&1 || true
pkg install -y wget unzip openjdk-17 gradle >/dev/null

echo "[২/৭] জাভা ভার্সন যাচাই হচ্ছে..."
java -version

if [ ! -d "$SDK_DIR/cmdline-tools/latest" ]; then
  echo "[৩/৭] Android SDK command-line tools ডাউনলোড হচ্ছে (একবারই লাগবে)..."
  mkdir -p "$SDK_DIR/cmdline-tools"
  cd "$SDK_DIR"
  wget -q "https://dl.google.com/android/repository/commandlinetools-linux-${CMDLINE_VER}_latest.zip" -O cmdline-tools.zip
  unzip -q cmdline-tools.zip -d cmdline-tools-tmp
  mv cmdline-tools-tmp/cmdline-tools "$SDK_DIR/cmdline-tools/latest"
  rm -rf cmdline-tools-tmp cmdline-tools.zip
else
  echo "[৩/৭] Android SDK আগে থেকেই ইনস্টল করা আছে, স্কিপ করা হলো।"
fi

export ANDROID_HOME="$SDK_DIR"
export ANDROID_SDK_ROOT="$SDK_DIR"
export PATH="$SDK_DIR/cmdline-tools/latest/bin:$SDK_DIR/platform-tools:$PATH"

echo "[৪/৭] Android SDK লাইসেন্স গ্রহণ করা হচ্ছে..."
yes | sdkmanager --licenses >/dev/null 2>&1 || true

echo "[৫/৭] প্ল্যাটফর্ম ও বিল্ড-টুলস ইনস্টল হচ্ছে (platform 34, build-tools 34.0.0)..."
sdkmanager "platform-tools" "platforms;android-34" "build-tools;34.0.0" >/dev/null

echo "sdk.dir=$SDK_DIR" > "$PROJECT_DIR/local.properties"

cd "$PROJECT_DIR"
if [ ! -f "./gradlew" ]; then
  echo "[৬/৭] Gradle wrapper তৈরি হচ্ছে..."
  gradle wrapper --gradle-version 8.7 >/dev/null
  chmod +x ./gradlew
else
  chmod +x ./gradlew
fi

echo "[৭/৭] অ্যাপ বিল্ড হচ্ছে (প্রথমবার কয়েক মিনিট লাগতে পারে)..."
./gradlew assembleDebug --no-daemon

APK_PATH="$PROJECT_DIR/app/build/outputs/apk/debug/app-debug.apk"

if [ -f "$APK_PATH" ]; then
  echo ""
  echo "✅ বিল্ড সফল হয়েছে!"
  echo "APK পাওয়া যাবে এখানে: $APK_PATH"

  if command -v termux-setup-storage >/dev/null 2>&1; then
    termux-setup-storage || true
    if [ -d "$HOME/storage/downloads" ]; then
      cp "$APK_PATH" "$HOME/storage/downloads/SadiaAI.apk"
      echo "📂 APK কপি করা হয়েছে: Downloads/SadiaAI.apk"
    fi
  fi

  if command -v termux-open >/dev/null 2>&1; then
    echo "📲 ইনস্টলার খোলা হচ্ছে..."
    termux-open "$APK_PATH" || echo "স্বয়ংক্রিয়ভাবে খোলা যায়নি — Downloads/SadiaAI.apk-তে গিয়ে নিজে ইনস্টল করুন।"
  else
    echo "ℹ️  'pkg install termux-api' করে আবার চালালে APK-টি নিজে থেকেই ইনস্টলারে খুলে যাবে।"
    echo "   অথবা এখনই: কোনো ফাইল ম্যানেজার দিয়ে উপরের পাথ থেকে APK-তে ট্যাপ করে ইনস্টল করুন।"
  fi
else
  echo "❌ বিল্ড ব্যর্থ হয়েছে। উপরের এরর লগ দেখুন।"
  exit 1
fi
